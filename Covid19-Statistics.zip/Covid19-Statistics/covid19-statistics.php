<?php
/*
Plugin Name: Covid19 Statistics
Description: Creates customizable widget to showcase Covid19 statistics issued by Health Promotion Bureau.
Version: 1.0
Author: Pathum Senaratna
*/

// The widget class
class Covid19_Stats_Widget extends WP_Widget {
	
	

	// Main constructor
	public function __construct() {
		parent::__construct(
			'covid19_stats_widget',
			__( 'Covid19 Statistics Widget', 'text_domain' ),
			array(
				'customize_selective_refresh' => true,
			)
		);
	}

	// The widget form (for the backend )
	public function form( $instance ) {
		
		

		// Set widget defaults
		$defaults = array(
			'title'    => '',
			'text'     => '',
		);
		
		// Parse current settings with defaults
		extract( wp_parse_args( ( array ) $instance, $defaults ) ); ?>

		<?php // Widget Title ?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php _e( 'Widget Title', 'text_domain' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>

		<?php // Text Field ?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'text' ) ); ?>"><?php _e( 'Text:', 'text_domain' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'text' ) ); ?>" type="text" value="<?php echo esc_attr( $text ); ?>" />
		</p>	


	<?php }
	
	public function update_stats(){

        // Include Request and Response classes
		
		$url= 'https://www.hpb.health.gov.lk/api/get-current-statistical';

		$arrContextOptions=array(
			  "ssl"=>array(
					"verify_peer"=>false,
					"verify_peer_name"=>false,
				),
			);  

		$response = file_get_contents($url, false, stream_context_create($arrContextOptions));
		$result = json_decode($response, true);

		return $result['data'];
		
	}

	// Update widget settings
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title']    = isset( $new_instance['title'] ) ? wp_strip_all_tags( $new_instance['title'] ) : '';
		$instance['text']     = isset( $new_instance['text'] ) ? wp_strip_all_tags( $new_instance['text'] ) : '';
		return $instance;
	}

	// Display the widget
	public function widget( $args, $instance ) {

		extract( $args );

		// Check the widget options
		$title    = isset( $instance['title'] ) ? apply_filters( 'widget_title', $instance['title'] ) : '';
		$text     = isset( $instance['text'] ) ? $instance['text'] : '';
		$data = $this->update_stats();
		// WordPress core before_widget hook (always include )
		echo $before_widget;

		// Display the widget
		echo '<div class="widget-text wp_widget_plugin_box">';

			// Display widget title if defined
			if ( $title ) {
				echo $before_title . $title . $after_title;
			}

			// Display text field
			if ( $text ) {
				echo '<p>' . $text . '</p>';
			}
?>
<style>
	#tablePreview tr:hover{
		
		background-color: #dee2e6;
	}

	#tablePreview thead th {
		background-color: #1d96b2;
		border: 1px solid #1d96b2;
		font-weight: normal;
		font-size:small;
		text-align: center;
		color: white;
	}

	#tablePreview tbody {
		border-left: 1px solid #1d96b2;
		border-bottom: 1px solid #1d96b2;
		font-size:small;
		color: #5e5d52;
		text-align: center;
	}
</style>

<div style="overflow-x:auto;">
	<!--Table-->
	<table id="tablePreview" class="w3-hoverable">
	<!--Table head-->
	  <thead>
		<tr>
		  <th>Region</th>
		  <th>Total</th>
		  <th>New</th>
		  <th>In hospitals</th>
		  <th>Deaths</th>
		  <th>New Deaths</th>
		  <th>Recovered</th>
		</tr>
	  </thead>
	  <!--Table head-->
	  <!--Table body-->
	  <tbody>
		
		<tr>
		  <td>Sri Lanka</td>
		  <td><?php echo $data['local_total_cases']; ?></td>
		  <td><?php echo $data['local_new_cases']; ?></td>
		  <td><?php echo $data['local_total_number_of_individuals_in_hospitals']; ?></td>
		  <td><?php echo $data['local_deaths']; ?></td>
		  <td> - </td>
		  <td><?php echo $data['local_recovered']; ?></td>
		</tr>
		
		<tr>
		  <td>Global</td>
		  <td><?php echo $data['global_total_cases']; ?></td>
		  <td><?php echo $data['global_new_cases']; ?></td>
		  <td> - </td>
		  <td><?php echo $data['global_deaths']; ?></td>
		  <td><?php echo $data['global_new_deaths']; ?></td>
		  <td><?php echo $data['global_recovered']; ?></td>
		</tr>

	  </tbody>
	  <!--Table body-->
	</table>
	<p style="font-size:10px;text-align: center;">Updated Date: <?php echo $data['update_date_time']; ?> <br/>Powered By Health Promotion Bureau Sri Lanka</p>
	<!--Table-->
</div>

<?php

		echo '</div>';

		// WordPress core after_widget hook (always include )
		echo $after_widget;

	}

}

// Register the widget
function register_covid19_stats_widget() {
	register_widget( 'Covid19_Stats_Widget' );
}
add_action( 'widgets_init', 'register_covid19_stats_widget' );